package com.example.finalproject.Generic;

public interface Client {
    String HTTPS = "http://";
    String ADMIN_BASE_URL = "192.168.1.16/Eventoo/api/";
}
