package com.example.finalproject.Model;

public class EventResponse {
    public Boolean error;
    public String message;
    public EventData event;

}
