package com.example.finalproject.Model;

public class UserData {
    public String email, username, phone_no;
}
