package com.example.finalproject.Model;

public class EventData {
    public String title, description, start_time, venue;

}
