package com.example.finalproject.Model;

public class LoginResponse {
    public Boolean error;
    public String message;
    public UserData normaluser;
}
